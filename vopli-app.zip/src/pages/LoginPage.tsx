import React from "react";
import Lottie from "lottie-react";
import animationData from '../assets/security.json'

const LoginPage: React.FC = (): JSX.Element => {

  /* const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice"
    }
  }; */
  const style = {
    width: '90px'
  }
    return (
      <React.Fragment>
        <Lottie 
        animationData={animationData}
        style={style} />
      </React.Fragment>
  );
}

export default LoginPage