import axios from 'axios'

export default axios.create({
    baseURL: process.env.REACT_APP_SERVER_URL,
    timeout: 5000,
    headers: {'Access-Control-Allow-Origin': '*'}
});